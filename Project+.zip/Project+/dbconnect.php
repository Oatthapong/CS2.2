<!--<link href="css/style.css" rel="stylesheet">-->
<?php
$con = mysqli_connect("localhost", "root", "", "mydata") or die("เกิดข้อผิดพลาดเกิดขึ้น");
mysqli_set_charset($con, "utf8");
